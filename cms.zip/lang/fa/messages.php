<?php
return [
    'contents' => [
        'store' => [
            'failed' => [
                'required' => 'فیلد :title احباری است.',
                'file'     => 'فیلد :title باید فایل باشد.',
                'string'   => 'فیلد :title باید حروف یا اعداد باشد.',
            ],
        ],
    ],
    'comments' => [
        'failed' => [
            'already_exists' => 'امکان ثبت نظر تکراری وجود ندارد.'
        ]
    ]
];